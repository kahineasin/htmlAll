﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateYjqueryApplication.Model
{
    public class SearchGridTemplateModel: TemplateModel
    {
        public List<string> SearchFields { get; set; }
        public List<DataGridViewColumn> GridColumns { get; set; }
    }
}
