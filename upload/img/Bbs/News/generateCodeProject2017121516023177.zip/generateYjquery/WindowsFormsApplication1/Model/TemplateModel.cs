﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerateYjqueryApplication.Model
{
    public class TemplateModel
    {
        public string FunctionName { get; set; }
        public string FunctionNameCN { get; set; }
    }
}
