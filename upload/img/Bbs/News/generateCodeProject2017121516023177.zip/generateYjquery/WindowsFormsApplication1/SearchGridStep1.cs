﻿using GenerateYjqueryApplication.Model;
using GenerateYjqueryApplication.Utils;
using RazorEngine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GenerateYjqueryApplication.Data;

namespace GenerateYjqueryApplication
{
    public partial class SearchGridStep1 : Form
    {
        public SearchGridStep1()
        {
            InitializeComponent();
        }

        private void SearchGridStep1_Load(object sender, EventArgs e)
        {

        }

        private void searchFieldCLBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void generateBtn_Click(object sender, EventArgs e)
        {
            var searchItems= searchFieldCLBox.CheckedItems as IList<string>;
            var searchFields = searchFieldCLBox.GetCheckedText();

            var model = new SearchGridTemplateModel
            {
                FunctionName = functionNameTBox.Text,
                FunctionNameCN = functionNameCNTBox.Text,
                SearchFields = searchFields
            };
            
            //根据column生成grid列
            var rows = gridFieldsGView.Rows;
            model.GridColumns = rows.RowToColumn();

            TemplateHelper.GenerateCode("SearchGrid", functionNameTBox.Text,  model);
        }

        private void functionNameTBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void inputSqlBtn_Click(object sender, EventArgs e)
        {
            var sqlPopups = new InputSqlPopups();
            //sqlPopups.FormClosing += new FormClosingEventHandler(this.OnSqlPopupsClosing);
            sqlPopups.ClickEvent += new ClickDelegateHander(OnSqlPopupsClosing);//注册事件
            sqlPopups.Show();
        }
        private void OnSqlPopupsClosing(DataTable dataTable) {
            if (dataTable != null) {
                foreach (DataColumn column in dataTable.Columns)
                {
                    DataGridViewRow row = new DataGridViewRow();
                    DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                    colNameCell.Value = column.ColumnName;
                    row.Cells.Add(colNameCell);
                    DataGridViewTextBoxCell colTypeCell = new DataGridViewTextBoxCell();//DataGridViewComboBoxCell
                    colTypeCell.Value = column.DataType;
                    row.Cells.Add(colTypeCell);
                    DataGridViewTextBoxCell colNameCNCell = new DataGridViewTextBoxCell();
                    colNameCNCell.Value = DataTableExtend.GetHeaderText(column.ColumnName);
                    row.Cells.Add(colNameCNCell);
                    gridFieldsGView.Rows.Add(row);
                }
                Activate();
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            var  selects = gridFieldsGView.SelectedRows;
            foreach (DataGridViewRow i in selects) {
                if (!i.IsNewRow)
                {
                    gridFieldsGView.Rows.Remove(i);
                }
            }
        }
    }
}
