using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace GenerateYjqueryApplication.Data
{
	/// <summary>
	/// DataBase ��ժҪ˵����
	/// </summary>
	public class DataBase
	{
        protected string _connectionstring = "data source=10.0.0.11;initial catalog=yjquery;persist security info=False;user id=sa;password=perfect;Connect Timeout=2000";// ConfigurationManager.ConnectionStrings["yjquery"].ConnectionString;
		protected SqlConnection _sqlconnection=new SqlConnection();
		public DataBase()
		{
			_sqlconnection.ConnectionString=_connectionstring;
			if(_sqlconnection.State!=ConnectionState.Open)
				_sqlconnection.Open();
		}
		public DataBase(string _connString)
		{
			_connectionstring=_connString;
			_sqlconnection.ConnectionString=_connectionstring;
			if(_sqlconnection.State!=ConnectionState.Open)
				_sqlconnection.Open();
		}

        public void Connection(string _connString)
        {
            _connectionstring = _connString;

            if (_sqlconnection.State == ConnectionState.Open)
            {
                _sqlconnection.Close();
            }
            _sqlconnection.ConnectionString = _connectionstring;
            _sqlconnection.Open();
        }

	}
}
