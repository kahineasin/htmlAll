using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;

namespace GenerateYjqueryApplication.Data
{
	/// <summary>
	/// SqlExecute ��ժҪ˵����
	/// </summary>
	public class ProcManager:DataBase
    {
        protected SqlCommand sqlCmd = new SqlCommand();
        protected SqlDataAdapter sqlda = new SqlDataAdapter();
        protected DataSet ds = new DataSet("Customer");

        public SqlParameterCollection ParameterArray = null;
        public string ErrorMessage;
        /// <summary>
        /// ִ�����ݿ��ѯ��䣬���ؽ��Ϊ���ṹ
        /// </summary>
        /// <returns>�����</returns>
        public DataTable GetQueryTable(string sqlval)
        {
            sqlCmd.Connection = this._sqlconnection;
            if (this._sqlconnection.State == ConnectionState.Closed)
                this._sqlconnection.Open();
            sqlCmd.CommandTimeout = 0;
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = sqlval;
            sqlda.SelectCommand = sqlCmd;
            try
            {
                ds.Tables.Clear();
                sqlda.Fill(ds);
                //����������
                ParameterArray = sqlCmd.Parameters;
                this._sqlconnection.Close();
                return ds.Tables[0];
            }
            catch (System.Exception ex)
            {
                ErrorMessage = ex.Message;
                this._sqlconnection.Close();
                return null;
            }
        }


        /// <summary>
        /// �๹�캯��
        /// </summary>
        /// <returns></returns>
        public ProcManager()
		{
		}
		/// <summary>
		/// �๹�캯����������������ݿ�������ַ���
		/// </summary>
		/// <returns></returns>
		public ProcManager(string connectionString):base(connectionString){}
	}
}
