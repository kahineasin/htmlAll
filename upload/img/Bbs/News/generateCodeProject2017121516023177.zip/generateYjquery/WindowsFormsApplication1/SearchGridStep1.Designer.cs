﻿namespace GenerateYjqueryApplication
{
    partial class SearchGridStep1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.searchFieldCLBox = new System.Windows.Forms.CheckedListBox();
            this.generateBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.functionNameTBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.functionNameCNTBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gridFieldsGView = new System.Windows.Forms.DataGridView();
            this.inputSqlBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.ColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNameCN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gridFieldsGView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "SearchField:";
            // 
            // searchFieldCLBox
            // 
            this.searchFieldCLBox.FormattingEnabled = true;
            this.searchFieldCLBox.Items.AddRange(new object[] {
            "Hybh",
            "Province",
            "Month",
            "Pos"});
            this.searchFieldCLBox.Location = new System.Drawing.Point(30, 56);
            this.searchFieldCLBox.Name = "searchFieldCLBox";
            this.searchFieldCLBox.Size = new System.Drawing.Size(117, 68);
            this.searchFieldCLBox.TabIndex = 1;
            this.searchFieldCLBox.SelectedIndexChanged += new System.EventHandler(this.searchFieldCLBox_SelectedIndexChanged);
            // 
            // generateBtn
            // 
            this.generateBtn.Location = new System.Drawing.Point(30, 441);
            this.generateBtn.Name = "generateBtn";
            this.generateBtn.Size = new System.Drawing.Size(95, 23);
            this.generateBtn.TabIndex = 2;
            this.generateBtn.Text = "Generate";
            this.generateBtn.UseVisualStyleBackColor = true;
            this.generateBtn.Click += new System.EventHandler(this.generateBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "FunctionName:";
            // 
            // functionNameTBox
            // 
            this.functionNameTBox.Location = new System.Drawing.Point(113, 10);
            this.functionNameTBox.Name = "functionNameTBox";
            this.functionNameTBox.Size = new System.Drawing.Size(100, 21);
            this.functionNameTBox.TabIndex = 4;
            this.functionNameTBox.TextChanged += new System.EventHandler(this.functionNameTBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(219, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "FunctionNameCN:";
            // 
            // functionNameCNTBox
            // 
            this.functionNameCNTBox.Location = new System.Drawing.Point(320, 10);
            this.functionNameCNTBox.Name = "functionNameCNTBox";
            this.functionNameCNTBox.Size = new System.Drawing.Size(100, 21);
            this.functionNameCNTBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "Genarate Column By Sql:";
            // 
            // gridFieldsGView
            // 
            this.gridFieldsGView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridFieldsGView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnName,
            this.ColumnType,
            this.ColumnNameCN});
            this.gridFieldsGView.Location = new System.Drawing.Point(30, 176);
            this.gridFieldsGView.Name = "gridFieldsGView";
            this.gridFieldsGView.RowTemplate.Height = 23;
            this.gridFieldsGView.Size = new System.Drawing.Size(366, 221);
            this.gridFieldsGView.TabIndex = 9;
            // 
            // inputSqlBtn
            // 
            this.inputSqlBtn.Location = new System.Drawing.Point(32, 147);
            this.inputSqlBtn.Name = "inputSqlBtn";
            this.inputSqlBtn.Size = new System.Drawing.Size(75, 23);
            this.inputSqlBtn.TabIndex = 10;
            this.inputSqlBtn.Text = "input Sql";
            this.inputSqlBtn.UseVisualStyleBackColor = true;
            this.inputSqlBtn.Click += new System.EventHandler(this.inputSqlBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(113, 147);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 23);
            this.deleteBtn.TabIndex = 11;
            this.deleteBtn.Text = "DeleteRow";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // ColumnName
            // 
            this.ColumnName.HeaderText = "列名";
            this.ColumnName.Name = "ColumnName";
            // 
            // ColumnType
            // 
            this.ColumnType.HeaderText = "列类型";
            this.ColumnType.Name = "ColumnType";
            // 
            // ColumnNameCN
            // 
            this.ColumnNameCN.HeaderText = "中文列名";
            this.ColumnNameCN.Name = "ColumnNameCN";
            // 
            // SearchGridStep1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 476);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.inputSqlBtn);
            this.Controls.Add(this.gridFieldsGView);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.functionNameCNTBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.functionNameTBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.generateBtn);
            this.Controls.Add(this.searchFieldCLBox);
            this.Controls.Add(this.label1);
            this.Name = "SearchGridStep1";
            this.Text = "SearchGridStep1";
            this.Load += new System.EventHandler(this.SearchGridStep1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridFieldsGView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox searchFieldCLBox;
        private System.Windows.Forms.Button generateBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox functionNameTBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox functionNameCNTBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView gridFieldsGView;
        private System.Windows.Forms.Button inputSqlBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNameCN;
    }
}