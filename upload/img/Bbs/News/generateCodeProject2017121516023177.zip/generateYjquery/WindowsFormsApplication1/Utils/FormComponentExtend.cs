﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateYjqueryApplication
{
    public static class FormComponentExtend
    {
        public static List<string> GetCheckedText(this CheckedListBox com) {
            var result = new List<string>();
            var item = com.CheckedItems;
            if (item.Count != 0)
            {
                for (int i = 0; i < item.Count; i++)
                {
                    result.Add((string)item[i]); 
                }
            }
            return result;
        }
    }
}
