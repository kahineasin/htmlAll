﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateYjqueryApplication.Utils
{
    public static class DataTableExtend
    {
        public static List<DataGridViewColumn> RowToColumn(this DataGridViewRowCollection rows) {
            var aa = rows.Count;
            var result = new List<DataGridViewColumn>();
            for (var i=0;i<rows.Count-1;i++ ) {//最后一行是新增行,要忽略
                DataGridViewRow row = rows[i];
                var col = new DataGridViewColumn() {
                    Name = (string)row.Cells[0].Value,
                    //DataType =(Type) row.Cells[1].Value,//可以考虑根据数据类型调整列格式
                    HeaderText= GetHeaderText((string)row.Cells[2].Value)
                };
                result.Add(col);
            }
            return result;
        }

        public static string GetHeaderText(string columnName) {
            var result = columnName;
            switch (result)
            {
                case "id":
                    result = "序号";
                    break;
                case "hyxm":
                    result = "会员姓名";
                    break;
                case "hybh":
                    result = "会员编号";
                    break;
                case "sf":
                    result = "省份";
                    break;
                case "tel":
                    result = "电话号码";
                    break;
                case "sfz":
                    result = "身份证号码";
                    break;
                default:
                    break;
            }
            return result;
        }
        
    }
}
