﻿using GenerateYjqueryApplication.Utils;
using RazorEngine;
using RazorEngine.Templating;
using System;
using System.IO;
using System.Text;

namespace GenerateYjqueryApplication
{
    [Flags]
    public enum TemplateType {
        View=1,
        ViewCode=2,
        ViewDesigner = 4
    }
    public static class TemplateHelper
    {
        public static string GetTemplate(string pageType, string codeType)
        {
            var templatePath = AppDomain.CurrentDomain.BaseDirectory + string.Format("//Template//{0}//{1}.cshtml",pageType,codeType);//= HttpContext.Current.Server.MapPath(String.Format("~/Areas/Sys/TemplateGuid/{0}/{1}.cshtml", pageType, codeType));
            var template = ZFiles.ReadTxtFile(templatePath);
            return template;
        }
        public static string GetFilePath(string path, string fileName = "")
        {
            var server = AppDomain.CurrentDomain.BaseDirectory;
            ZFiles.CreateDirectory(server+"//"+ path);
            return server + "//" + path+"//" + fileName;
        }

        public static Stream GetStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            UTF8Encoding utf8 = new UTF8Encoding(true);
            StreamWriter writer = new StreamWriter(stream, utf8);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        public static void GenerateCode<T>(string functionType,string functionName,T model, TemplateType type= TemplateType.View| TemplateType.ViewCode|TemplateType.ViewDesigner)
        {
            var codePath = "GenerateCode//" + functionName;
            var viewCode = "";
            var keyPrev = Guid.NewGuid();
            if (type.HasFlag(TemplateType.View))
            {
                 viewCode = Engine.Razor.RunCompile(GetTemplate(functionType, "View"), keyPrev+"templateKeyView".ToString(), null, model);   
                ZFiles.SaveStreamToFile(GetStreamFromString(viewCode), GetFilePath(codePath, functionName + ".aspx"));
            }
            if (type.HasFlag(TemplateType.ViewCode))
            {
                 viewCode = Engine.Razor.RunCompile(GetTemplate(functionType, "ViewCode"), keyPrev+"templateKeyViewCode", null, model);
                ZFiles.SaveStreamToFile(GetStreamFromString(viewCode), GetFilePath(codePath, functionName + ".aspx.cs"));
            }
            if (type.HasFlag(TemplateType.ViewDesigner))
            {
                viewCode = Engine.Razor.RunCompile("", keyPrev + "templateKeyViewDesigner");//生成空文件以便项目能识别
                ZFiles.SaveStreamToFile(GetStreamFromString(viewCode), GetFilePath(codePath, functionName + ".aspx.designer.cs"));
            }
            var enumType = typeof(TemplateType);

            System.Diagnostics.Process.Start(GetFilePath(codePath)); //如果是本地访问就直接打开文件夹
        }

    }
}
