﻿namespace GenerateYjqueryApplication
{
    partial class SelectFunctionType
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.searchGridBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // searchGridBtn
            // 
            this.searchGridBtn.Location = new System.Drawing.Point(29, 24);
            this.searchGridBtn.Name = "searchGridBtn";
            this.searchGridBtn.Size = new System.Drawing.Size(75, 23);
            this.searchGridBtn.TabIndex = 0;
            this.searchGridBtn.Text = "searchGridBtn";
            this.searchGridBtn.UseVisualStyleBackColor = true;
            this.searchGridBtn.Click += new System.EventHandler(this.searchGridBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "ChooseType:";
            // 
            // SelectFunctionType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchGridBtn);
            this.Name = "SelectFunctionType";
            this.Text = "SelectFunctionType";
            this.Load += new System.EventHandler(this.SelectFunctionType_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button searchGridBtn;
        private System.Windows.Forms.Label label1;
    }
}

