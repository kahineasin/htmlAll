﻿using GenerateYjqueryApplication.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GenerateYjqueryApplication
{
    public delegate void ClickDelegateHander(DataTable message); //声明一个委托
    public partial class InputSqlPopups : Form
    {
        public event ClickDelegateHander ClickEvent;//声明一个事件
        public DataTable DataTable { get; set; }
        public InputSqlPopups()
        {
            InitializeComponent();
        }
        public InputSqlPopups(DataTable dt):this()
        {
            DataTable = dt;
            InitializeComponent();
        }


        private void confirmBtn_Click(object sender, EventArgs e)
        {
            //根据column生成grid列
            //var sql = string.Join(" ", sqlTBox.Lines.Skip(1));
            var sql = string.Join(" ", sqlTBox.Lines);
            if (!string.IsNullOrWhiteSpace(sql))
            {
                var proc = new ProcManager();
                DataTable = proc.GetQueryTable(sql);
                if (ClickEvent != null) //判断事件是否被注册
                    ClickEvent(DataTable);
                Close();
            }
        }
    }
}
