﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ReleaseProject
{
    public partial class Form1 : Form
    {
        private XmlNodeList _syses;
        private XmlDocument _xml;
        public static bool Ping(string remoteHost)
        {
            bool Flag = false;
            Process proc = new Process();
            try
            {
                proc.StartInfo.FileName = "cmd.exe";
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardInput = true;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardError = true;
                proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                //string dosLine = @"ping -n 1 " + remoteHost;
                string dosLine = @"ping  " + remoteHost;
                proc.StandardInput.WriteLine(dosLine);
                proc.StandardInput.WriteLine("exit");
                while (proc.HasExited == false)
                {
                    proc.WaitForExit(500);
                }
                string pingResult = proc.StandardOutput.ReadToEnd();
                //if (pingResult.IndexOf("(0% loss)") != -1)
                if (pingResult.IndexOf("(0%") != -1)
                {
                    Flag = true;
                }
                proc.StandardOutput.Close();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                try
                {
                    proc.Close();
                    proc.Dispose();
                }
                catch
                {
                }
            }
            return Flag;
        }

        public static bool Connect(string remoteHost, string userName, string passWord)
        {
            if (!Ping(remoteHost))
            {
                return false;
            }
            bool Flag = true;
            Process proc = new Process();
            try
            {
                proc.StartInfo.FileName = "cmd.exe";
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.RedirectStandardInput = true;
                proc.StartInfo.RedirectStandardOutput = true;
                proc.StartInfo.RedirectStandardError = true;
                proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                string dosLine = @"net use \\" + remoteHost + " " + passWord + " " + " /user:" + userName + ">NUL";
                proc.StandardInput.WriteLine(dosLine);
                proc.StandardInput.WriteLine("exit");
                while (proc.HasExited == false)
                {
                    proc.WaitForExit(1000);
                }
                string errormsg = proc.StandardError.ReadToEnd();
                if (errormsg != "")
                {
                    Flag = false;
                }
                proc.StandardError.Close();
            }
            catch (Exception ex)
            {
                Flag = false;
            }
            finally
            {
                try
                {
                    proc.Close();
                    proc.Dispose();
                }
                catch
                {
                }
            }
            return Flag;
        }
        public Form1()
        {
            InitializeComponent();

            //if (Connect("192.168.0.26", "REPORTSERVER\\Administrator", "perfect26"))
            //{
            //    //File.Copy("\\机器B\文件路径\文件名称", "机器A存放文件完整路径", true);
            //    var aa = "aa";
            //}

            string xmlfile=Path.Combine(AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", ""), "XmlConfig\\PathConfig.xml");
            _xml = new XmlDocument();
            _xml.Load(xmlfile);
            _syses = _xml.SelectSingleNode("Systems").ChildNodes;
            foreach (XmlNode sys in _syses)
            {
                DataGridViewRow row = new DataGridViewRow();

                DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                colNameCell.Value = sys.Name;
                row.Cells.Add(colNameCell);

                sysDgv.Rows.Add(row);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            var selects = sysDgv.SelectedRows;
            if (selects.Count != 1) { return; }
             var f = new UpdateForm(_xml.SelectSingleNode("Systems/" + (string)selects[0].Cells[0].Value));
            f.Show();
        }

        private void rollBackBtn_Click(object sender, EventArgs e)
        {
            var selects = sysDgv.SelectedRows;
            if (selects.Count != 1) { return; }
            var f = new RollBackForm(_xml.SelectSingleNode("Systems/" + (string)selects[0].Cells[0].Value));
            f.Show();
        }

        private void copyFileBtn_Click(object sender, EventArgs e)
        {
            var selects = sysDgv.SelectedRows;
            if (selects.Count != 1) { return; }
            var f = new CopyFileForm(_xml.SelectSingleNode("Systems/" + (string)selects[0].Cells[0].Value));
            f.Show();
        }
    }
}
