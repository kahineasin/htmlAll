﻿using PF.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace ReleaseProject
{
    public partial class RollBackForm : Form
    {
        //private List<UpdateFileModel> _updateFiles;
        private string _sysName = "";
        //private XmlNode _sys;
        private SysModel _sys;
        public RollBackForm()
        {
            InitializeComponent();
        }

        public RollBackForm(XmlNode sys):this()
        {
            _sys = new SysModel(sys);
            _sysName = sys.Name;


            var logsRoot = Path.Combine(ReleaseUtils.AppRoot, string.Format("UpdateLog\\{0}", _sysName));
            var logs=Directory.GetDirectories(logsRoot).OrderByDescending(a=>a);
            foreach(var log in logs)
            {
                DataGridViewRow row = new DataGridViewRow();

                DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                DateTime dt ;
                if (DateTime.TryParseExact(Path.GetFileName(log),ReleaseUtils.TimePathFormat, null, DateTimeStyles.None, out dt))
                {
                    colNameCell.Value = dt;
                }
                else
                {
                    colNameCell.Value = Path.GetFileName(log);
                }
                row.Cells.Add(colNameCell);
                //2
                DataGridViewTextBoxCell colPathCell = new DataGridViewTextBoxCell();
                colPathCell.Value = log;
                row.Cells.Add(colPathCell);

                logDgv.Rows.Add(row);
            }

            //当前版本
            currentVersionLb.Text = LogInfoModel.GetCurrentVersion(_sysName);
            //var logVerPath = Path.Combine(ReleaseUtils.AppRoot, "UpdateLog", _sysName, "LogInfo.txt");
            //if (File.Exists(logVerPath))
            //{
            //    var logInfo = new LogInfoModel(ZFiles.ReadTxtFile(logVerPath));
            //    currentVersionLb.Text = logInfo.CurrentVersion;
            //}
        }


        private void openLogBtn_Click(object sender, EventArgs e)
        {
            var selects = logDgv.SelectedRows;
            if (selects.Count != 1) { return; }

            System.Diagnostics.Process.Start((string)selects[0].Cells[1].Value); //如果是本地访问就直接打开文件夹

        }
        private void rollBackBtn_Click(object sender, EventArgs e)
        {
            var selects = logDgv.SelectedRows;
            if (selects.Count != 1) { return; }

            //var logTxt = new FileStream(Path.Combine((string)selects[0].Cells[1].Value,"log.txt"),FileMode.Open);
            var logPath = Path.Combine((string)selects[0].Cells[1].Value, "log.txt");
            var rollBackFiles = new List<RollBackFileModel>();
            using (FileStream fs = new FileStream(logPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader reader = new StreamReader(fs, Encoding.UTF8))
                {
                    //string text = string.Empty;
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (string.IsNullOrWhiteSpace(line)) { continue; }
                        var rollBackFile = new RollBackFileModel(line);
                        if (rollBackFile.RollBackWay == UpdateWay.Replace) {
                            rollBackFile.BackupFile = new FileStream(Path.Combine((string)selects[0].Cells[1].Value, "Server", rollBackFile.RelativePath), FileMode.Open);
                        }
                       
                        rollBackFiles.Add(rollBackFile);
                        //content = text;
                    }
                }
            }
            var f = new ConfirmRollBackForm(_sys, rollBackFiles,selects[0].Cells[0].Value.ToString());
            f.ClickEvent += new ConfirmDelegateHander(OnConfirm);//注册事件
            f.Show();
        }
        private void OnConfirm(string version)
        {
            currentVersionLb.Text = version;
        }
    }
}
