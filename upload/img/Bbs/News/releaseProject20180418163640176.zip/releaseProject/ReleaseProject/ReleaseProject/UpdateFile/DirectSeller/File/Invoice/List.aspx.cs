﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DirectSeller.classes.Web;
using DirectSeller.CollectInvoiceServiceReference;
using DirectSeller.classes.Commons;
using System.Data;
using Perfect;
using System.Collections;

namespace DirectSeller.Invoice
{
    public partial class List : //PageBase
        ExportListPageBase
    {
        /// <summary>
        /// 正式:http://192.168.250.8:12302/CollectInvoiceWebS.asmx 测试:http://192.168.205.73:12303/CollectInvoiceWebS.asmx
        /// </summary>
        private CollectInvoiceWebSSoapClient _service = new CollectInvoiceWebSSoapClient();
        protected classes.Agent agent = new DirectSeller.classes.Agent();
        protected string _selectDateFormat = "yyyy-MM-dd";
        protected string _dateFormat = "yyyy-MM-dd HH:mm:ss";
        protected MKeyValue[] _invoiceTypeList
        {
            get
            {
                return ViewState["_invoiceTypeList"] == null ? null : (MKeyValue[])ViewState["_invoiceTypeList"];
            }
            set
            {
                ViewState["_invoiceTypeList"] = value;
            }
        }
        protected void Page_Load(object sender, System.EventArgs e)
        {
            var fgsno = "";
            agent.getFgsName(Agentno, out fgsno);
            if (fgsno != "30000")
            {//发布时需要启用--wxjtodo
                Response.Write("<script type='text/javascript'>alert('只有江苏分公司可以访问');history.go(-1);</script>");
                Response.Flush();
                Response.End();
                return;
            }
            if (!this.IsPostBack)
            {
                tbbeginDT.Text = DateTime.Today.AddMonths(-1).ToString(_selectDateFormat);
                tbendDT.Text = DateTime.Today.AddDays(1).AddSeconds(-1).ToString(_selectDateFormat);

                _invoiceTypeList = _service.GetOptionList("CollectInvoice.InvoiceType");
                databind();
            }
        }
        protected string GetInvoiceTypeName(string code) { 
            var t=_invoiceTypeList.FirstOrDefault(a=>(string)a.Value==code);
            return t == null ? code : (string)t.Key;
        }

        private void databind()
        {
            string beginDT = tbbeginDT.Text;
            DateTime dBeginDT;
            if (DateTime.TryParse(beginDT, out dBeginDT))
            {
                beginDT = dBeginDT.ToString(_dateFormat);
            }
            string endDT = tbendDT.Text;
            DateTime dEndDT;
            if (DateTime.TryParse(endDT, out dEndDT))
            {
                endDT = dEndDT.AddDays(1).AddSeconds(-1).ToString(_dateFormat);
            }
            var data = _service.Agent_GetInvoiceList(Userno, Agentno, beginDT, endDT);
            if (data.Success)
            {
                dt = data.Value.ToDataTable<InvoiceDBInfo>();
                base.databind(MyPager1, MyList, null, lerror);


            }
        }

        #region Web 窗体设计器生成的代码
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: 该调用是 ASP.NET Web 窗体设计器所必需的。
            //
            InitializeComponent();
            base.OnInit(e);
        }


        /// <summary>
        /// 设计器支持所需的方法 - 不要使用代码编辑器修改
        /// 此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.MyPager1.PageChanged += new MyCustomControl.myPager.PageChangedEventHandler(this.MyPager1_PageChanged);
        }
        #endregion

        protected void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            databind();
        }

        protected void MyPager1_PageChanged(object src, MyCustomControl.PageChangedEventArgs e)
        {
            MyPager1.CurrentPageIndex = e.NewPageIndex;
            databind();
        }

        protected void MyList_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                var id = int.Parse(e.Item.GetCell("Id").Text);
                var data = new InvoiceDBInfo { Id = id, User = Userno };
                var result = _service.Agent_DeleteInvoice(data);
                if (result.Success)
                {
                    Pager.genAlertWindow( "删除成功" );
                    databind();
                }
                else
                {
                    Pager.genAlertWindow("删除失败");
                }
            }
        }

        protected void MyList_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
        {
            if (e.Item.ItemIndex > -1)
            {
                //Button btnCancel = (Button)e.Item.FindControl("btn_delete");
                LinkButton btnDelete = (LinkButton)e.Item.FindControl("btn_delete");
                Pager.RegisterConfirmWindow(btnDelete, "确认删除吗？");
            }
        }


    }
}