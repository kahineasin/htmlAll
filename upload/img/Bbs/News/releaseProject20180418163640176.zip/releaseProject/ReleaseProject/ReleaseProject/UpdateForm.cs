﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ReleaseProject
{
    public partial class UpdateForm : Form
    {
        private string _updateFileRoot;
        private List<UpdateFileModel> _updateFiles;
        private string _sysName = "";
        //private XmlNode _sys;
        private SysModel _sys;
        //private string appRoot = AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "");
        public UpdateForm()
        {
            InitializeComponent();
        }

        public UpdateForm(XmlNode sys):this()
        {
            _sys =new SysModel( sys);
            _sysName = sys.Name;

            //配置路径
            _updateFileRoot = Path.Combine(ReleaseUtils.AppRoot, "UpdateFile", _sysName, "File");

            clientTbx.Text = sys.SelectSingleNode("Client/SystemRoot").InnerText;
            serverTbx.Text = sys.SelectSingleNode("Server/SystemRoot").InnerText;

            var ufRoot = Path.Combine(ReleaseUtils.AppRoot, "UpdateFile", _sysName, "Temp");
            var ufFolderPath = Path.Combine(ufRoot, "UpdateFolder.txt");
            var ufFilePath = Path.Combine(ufRoot, "UpdateFile.txt");
            if (File.Exists(ufFolderPath))
            {
                AddFolderByTxt(ufFolderPath);

            }
            else
            {
                var folders = sys.SelectNodes("UpdatePaths/UpdatePath");
                foreach (XmlNode folder in folders)
                {
                    AddFolder(folder.SelectSingleNode("Path").InnerText, folder.SelectSingleNode("FileFormats").InnerText);
                }
            }
            if (File.Exists(ufFilePath))
            {
                AddFileByTxt(ufFilePath);
            }

        }
        #region AddRow
        private void AddFolderByTxt(string filePath)
        {
            ReleaseUtils.AddFolderGridRowByTxt(folderDgv, filePath);

        }
        private void AddFolder(string folderPath, string fileType)
        {
            ReleaseUtils.AddFolderGridRow(folderDgv, folderPath, fileType);

        }
        private void AddFileByTxt(string filePath)
        {
            ReleaseUtils.AddFileGridRowByTxt(fileDgv, filePath);

        }
        private void AddFile(string folderPath)
        {
            ReleaseUtils.AddFileGridRow(fileDgv, folderPath);

        }
        #endregion
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            DisposeFile();

            var sTime = DateTime.Now.ToString(ReleaseUtils.TimePathFormat);
            //var logPath = Path.Combine(appRoot, string.Format("UpdateLog\\{0}\\{1}", _sysName, sTime));

            //var file = new FileStream(logPath,FileMode.Create);//需要权限 
            _updateFiles = new List<UpdateFileModel>();
            foreach (DataGridViewRow row in folderDgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    //var cPath = Path.Combine(clientTbx.Text, (string)row.Cells[0].Value);
                    var arrExt = ((string)row.Cells[1].Value).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    string path = (string)row.Cells[0].Value;
                    var cPath = Path.Combine(_updateFileRoot, path);//正式时启用这一句 --wxj
                    var sPath = Path.Combine(serverTbx.Text, path);
                    foreach (var ext in arrExt)
                    {
                        var cFiles = Directory.GetFiles(cPath, ext);
                        var sFiles = Directory.GetFiles(sPath, ext);
        
                        foreach (var file in cFiles)
                        {
                            var updateFile = new UpdateFileModel { RelativePath = Path.Combine(path, Path.GetFileName(file)) };
                            if (cFiles.Contains(file))
                            {
                                updateFile.ClientFile = new FileStream(file, FileMode.Open,FileAccess.ReadWrite);
                            }
                            var sFile = sFiles.FirstOrDefault(a => Path.GetFileName(a) == Path.GetFileName(file));
                            if (sFile != null)
                            {
                                updateFile.ServerFile = new FileStream(sFile, FileMode.Open, FileAccess.ReadWrite);
                            }
                            //if (sFiles.Contains(file))
                            //{
                            //    updateFile.ServerFile = new FileStream(file, FileMode.Open);
                            //}
                            if (!IsAllTheSame(updateFile.ClientFile, updateFile.ServerFile))
                            {
                                _updateFiles.Add(updateFile);
                            }
                        }
                    }
                }
            }
            foreach (DataGridViewRow row in fileDgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    string path = (string)row.Cells[0].Value;

                    if (!_updateFiles.Any(a => a.RelativePath == path))
                    {
                        var cPath = Path.Combine(_updateFileRoot, path);//正式时启用这一句 --wxj
                        var sPath = Path.Combine(serverTbx.Text, path);

                        var updateFile = new UpdateFileModel { RelativePath = path };
                        if (File.Exists(cPath))
                        {
                            updateFile.ClientFile = new FileStream(cPath, FileMode.Open);
                        }
                        if (File.Exists(sPath))
                        {
                            updateFile.ServerFile = new FileStream(sPath, FileMode.Open);
                        }
                        if (!IsAllTheSame(updateFile.ClientFile, updateFile.ServerFile))
                        {
                            _updateFiles.Add(updateFile);
                        }
                    }
                }
            }
            var f = new ConfirmUpdateForm(_sys,_updateFiles);
            f.Show();
        }

        private bool IsAllTheSame(FileStream file1,FileStream file2) {

            if (file1 != null && file2 != null)
            {
                //计算第一个文件的哈希值
                var hash = System.Security.Cryptography.HashAlgorithm.Create();
                var stream_1 = file1;
                byte[] hashByte_1 = hash.ComputeHash(stream_1);
                //stream_1.Close();
                //计算第二个文件的哈希值
                var stream_2 = file2;
                byte[] hashByte_2 = hash.ComputeHash(stream_2);
                //stream_2.Close();

                //比较两个哈希值
                if (BitConverter.ToString(hashByte_1) == BitConverter.ToString(hashByte_2)) {
                    return true;
                } else {
                    return false;
                }
            }
            return false;
        }

        private void deleteFolderBtn_Click(object sender, EventArgs e)
        {
            var selects = folderDgv.SelectedRows;
            foreach (DataGridViewRow i in selects)
            {
                if (!i.IsNewRow)
                {
                    folderDgv.Rows.Remove(i);
                }
            }
        }
        private void deleteFileBtn_Click(object sender, EventArgs e)
        {
            var selects = fileDgv.SelectedRows;
            foreach (DataGridViewRow i in selects)
            {
                if (!i.IsNewRow)
                {
                    fileDgv.Rows.Remove(i);
                }
            }
        }

        private void addFolderBtn_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = new DataGridViewRow();
            folderDgv.Rows.Add(row);
        }

        private void addFileBtn_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = new DataGridViewRow();
            fileDgv.Rows.Add(row);
        }
        protected override void OnClosed(EventArgs e)
        {
            DisposeFile();
            base.OnClosed(e);
        }
        private void DisposeFile()
        {
            if (_updateFiles != null && _updateFiles.Count > 0)
            {
                foreach (var updateFile in _updateFiles)
                {
                    updateFile.DisposeFile();
                }
                _updateFiles.Clear();
            }
        }
    }
}
