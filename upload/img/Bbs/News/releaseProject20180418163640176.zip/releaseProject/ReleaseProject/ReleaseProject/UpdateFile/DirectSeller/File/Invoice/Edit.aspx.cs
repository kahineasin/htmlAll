﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DirectSeller.classes.Web;
using DirectSeller.CollectInvoiceServiceReference;
using DirectSeller.classes.Commons;
using System.Data;
using Perfect;

namespace DirectSeller.Invoice
{
    public partial class Edit : PageBase
    {
        protected DirectSeller.classes.Agent agent= new DirectSeller.classes.Agent();
        /// <summary>
        /// 正式:http://192.168.250.8:12302/CollectInvoiceWebS.asmx 测试:http://192.168.205.73:12303/CollectInvoiceWebS.asmx
        /// </summary>
        private CollectInvoiceWebSSoapClient _service = new CollectInvoiceWebSSoapClient();
        protected int? Id
        {
            get
            {
                return ViewState["_id"] == null ? null : (int?)ViewState["_id"];
            }
            set
            {
                ViewState["_id"] = value;
            }
        }
        protected bool ShowInvoiceFields
        {
            get
            {
                return ViewState["_showInvoiceFields"] == null ? (bool)(ViewState["_showInvoiceFields"] = true) : (bool)ViewState["_showInvoiceFields"];
            }
            set
            {
                ViewState["_showInvoiceFields"] = value;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                if (Request.QueryString["id"] != null)
                {
                    Id = int.Parse(Request.QueryString["id"]);
                }
                DirectSeller.classes.AgentInfo agentInfo = agent.GetAgentInfo(Agentno);
                tbAgentNo.Text = ""+Agentno+","+ agentInfo.AgentName+"";

                //下拉数据
                var typeList = _service.GetOptionList("CollectInvoice.BXLX");
                var invoiceTypeList = _service.GetOptionList("CollectInvoice.InvoiceType");

                PFNetHelper.DropDownListBind(typeList, ref ddlType, "Key", "Value");
                PFNetHelper.DropDownListBind(invoiceTypeList, ref ddlInvoiceType, "Key", "Value");

                PFNetHelper.BindModel("InvoiceDBInfo", new ModelBindConfigCollection { 
                    {ddlType,"Type",a=>{a.SetLabel(lbType);a.SetValidator(rfvType);}},
                    {tbAgentNo,"AgentNo",a=>a.SetLabel(lbAgentNo)},
                    {tbQRCodeStr,"QRCodeStr",a=>a.SetLabel(lbQRCodeStr)},
                    {ddlInvoiceType,"InvoiceType",a=>{a.SetLabel(lbInvoiceType);a.SetValidator(rfvInvoiceType);}},
                    {tbInvoiceCode,"InvoiceCode",a=>a.SetLabel(lbInvoiceCode)},
                    {tbInvoiceNo_From,"InvoiceNo_From",a=>a.SetLabel(lbInvoiceNo_From)},
                    {tbInvoiceNo_To,"InvoiceNo_To",a=>a.SetLabel(lbInvoiceNo_To)},
                    {tbInvoiceDate,"InvoiceDate",a=>a.SetLabel(lbInvoiceDate)},
                    {tbInvoiceCheckCode,"InvoiceCheckCode",a=>a.SetLabel(lbInvoiceCheckCode)},
                    {tbInvoiceAllMoney,"InvoiceAllMoney",a=>a.SetLabel(lbInvoiceAllMoney)}

                });

                databind();
            }
        }
        private void databind()
        {
            if (Id != null)
            {
                var result = _service.Agent_GetInvoice(Userno, Id.Value);
                if (result.Success)
                {
                    var dt = new List<InvoiceDBInfo> { result.Value }.ToDataTable();

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        PFNetHelper.SetControlByRow(dt.Rows[0], new Dictionary<Control, string>{
                            {ddlType,"Type"},
                            //{ddlAgentNo,"AgentNo"},
                            {ddlInvoiceType,"InvoiceType"},
                            {tbInvoiceCode,"InvoiceCode"},
                            {tbInvoiceNo_From,"InvoiceNo_From"},
                            {tbInvoiceNo_To,"InvoiceNo_To"},
                            {tbInvoiceDate,"InvoiceDate"},
                            {tbInvoiceCheckCode,"InvoiceCheckCode"},
                            {tbInvoiceAllMoney,"InvoiceAllMoney"}
                        });
                    }
                }
            }
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            if (Id.HasValue)//修改
            {
                var old = _service.Agent_GetInvoice(Userno, Id.Value);
                if (!old.Success) { ShowMsgByMasterPage("修改失败"); return; }
                var oldData = old.Value;

                ReadControlToObject(oldData, new Dictionary<Control, string>{
                    {ddlType,"Type"},
                    {ddlInvoiceType,"InvoiceType"},
                    {tbInvoiceCode,"InvoiceCode"},
                    {tbInvoiceNo_From,"InvoiceNo_From"},
                    {tbInvoiceNo_To,"InvoiceNo_To"},
                    {tbInvoiceDate,"InvoiceDate"},
                    {tbInvoiceCheckCode,"InvoiceCheckCode"},
                    {tbInvoiceAllMoney,"InvoiceAllMoney"}
                });

                var result = _service.Agent_EditInvoice(oldData);
                if (!result.Success) { ShowMsgByMasterPage(result.Message); return; }

                SaveSuccess(result.Message);

            }
            else
            { //新增

                var data = new CollectInvoiceInfo { User = Userno, AgentNo = Agentno };
                ReadControlToObject(data, new Dictionary<Control, string>{
                    {ddlType,"Type"},
                    {tbQRCodeStr,"QRCodeStr"},
                    {ddlInvoiceType,"InvoiceType"},
                    {tbInvoiceCode,"InvoiceCode"},
                    {tbInvoiceNo_From,"InvoiceNo_From"},
                    {tbInvoiceNo_To,"InvoiceNo_To"},
                    {tbInvoiceDate,"InvoiceDate"},
                    {tbInvoiceCheckCode,"InvoiceCheckCode"},
                    {tbInvoiceAllMoney,"InvoiceAllMoney"}
                });
                var result = _service.Agent_AddInvoice(data);
                if (!result.Success) { ShowMsgByMasterPage(result.Message); return; }

                SaveSuccess(result.Message);

            }
        }
        private void SaveSuccess(string tip)
        {
            this.ClientScript.RegisterStartupScript(this.GetType(), "refreshList" + tip,
            "<script>alert('" + tip + "');parent.parent.GB_hide();parent.parent.refresh();</script>");
        }

        protected void tbQRCodeStr_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbQRCodeStr.Text) && (!ShowInvoiceFields))
            {
                EnableInvoiceFields(true);

            }
            else if ((!string.IsNullOrWhiteSpace(tbQRCodeStr.Text)) && (ShowInvoiceFields))
            {
                EnableInvoiceFields(false);
                btn_save_Click(null, null);
            }
        }
        private void EnableInvoiceFields(bool enable)
        {
            ddlInvoiceType.Enabled =
                tbInvoiceCode.Enabled =
                tbInvoiceNo_From.Enabled =
                tbInvoiceNo_To.Enabled =
                tbInvoiceDate.Enabled =
                tbInvoiceCheckCode.Enabled =
                tbInvoiceAllMoney.Enabled =
                rfvInvoiceType.Enabled =
                rfvInvoiceCode.Enabled =
                rfvInvoiceNo_From.Enabled = enable;
            ShowInvoiceFields = enable;
        }
    }
}