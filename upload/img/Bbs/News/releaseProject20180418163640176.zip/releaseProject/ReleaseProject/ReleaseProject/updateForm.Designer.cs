﻿namespace ReleaseProject
{
    partial class UpdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderDgv = new System.Windows.Forms.DataGridView();
            this.FolderPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FileType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fileDgv = new System.Windows.Forms.DataGridView();
            this.FilePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientTbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.serverTbx = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.updateBtn = new System.Windows.Forms.Button();
            this.deleteFolderBtn = new System.Windows.Forms.Button();
            this.deleteFileBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.folderDgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // folderDgv
            // 
            this.folderDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.folderDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FolderPath,
            this.FileType});
            this.folderDgv.Location = new System.Drawing.Point(12, 119);
            this.folderDgv.Name = "folderDgv";
            this.folderDgv.RowTemplate.Height = 23;
            this.folderDgv.Size = new System.Drawing.Size(240, 150);
            this.folderDgv.TabIndex = 0;
            // 
            // FolderPath
            // 
            this.FolderPath.HeaderText = "FolderPath";
            this.FolderPath.Name = "FolderPath";
            // 
            // FileType
            // 
            this.FileType.HeaderText = "FileType";
            this.FileType.Name = "FileType";
            // 
            // fileDgv
            // 
            this.fileDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fileDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FilePath});
            this.fileDgv.Location = new System.Drawing.Point(270, 119);
            this.fileDgv.Name = "fileDgv";
            this.fileDgv.RowTemplate.Height = 23;
            this.fileDgv.Size = new System.Drawing.Size(240, 150);
            this.fileDgv.TabIndex = 1;
            // 
            // FilePath
            // 
            this.FilePath.HeaderText = "FilePath";
            this.FilePath.Name = "FilePath";
            // 
            // clientTbx
            // 
            this.clientTbx.Enabled = false;
            this.clientTbx.Location = new System.Drawing.Point(74, 37);
            this.clientTbx.Name = "clientTbx";
            this.clientTbx.Size = new System.Drawing.Size(287, 21);
            this.clientTbx.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Client";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(367, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Server";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // serverTbx
            // 
            this.serverTbx.Location = new System.Drawing.Point(74, 67);
            this.serverTbx.Name = "serverTbx";
            this.serverTbx.Size = new System.Drawing.Size(287, 21);
            this.serverTbx.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(367, 66);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "系统路径";
            // 
            // updateBtn
            // 
            this.updateBtn.Location = new System.Drawing.Point(12, 291);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 23);
            this.updateBtn.TabIndex = 9;
            this.updateBtn.Text = "更新";
            this.updateBtn.UseVisualStyleBackColor = true;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // deleteFolderBtn
            // 
            this.deleteFolderBtn.Location = new System.Drawing.Point(12, 94);
            this.deleteFolderBtn.Name = "deleteFolderBtn";
            this.deleteFolderBtn.Size = new System.Drawing.Size(56, 23);
            this.deleteFolderBtn.TabIndex = 10;
            this.deleteFolderBtn.Text = "Delete";
            this.deleteFolderBtn.UseVisualStyleBackColor = true;
            this.deleteFolderBtn.Click += new System.EventHandler(this.deleteFolderBtn_Click);
            // 
            // deleteFileBtn
            // 
            this.deleteFileBtn.Location = new System.Drawing.Point(270, 94);
            this.deleteFileBtn.Name = "deleteFileBtn";
            this.deleteFileBtn.Size = new System.Drawing.Size(56, 23);
            this.deleteFileBtn.TabIndex = 12;
            this.deleteFileBtn.Text = "Delete";
            this.deleteFileBtn.UseVisualStyleBackColor = true;
            // 
            // UpdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 376);
            this.Controls.Add(this.deleteFileBtn);
            this.Controls.Add(this.deleteFolderBtn);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.serverTbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clientTbx);
            this.Controls.Add(this.fileDgv);
            this.Controls.Add(this.folderDgv);
            this.Name = "UpdateForm";
            this.Text = "updateForm";
            ((System.ComponentModel.ISupportInitialize)(this.folderDgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView folderDgv;
        private System.Windows.Forms.DataGridView fileDgv;
        private System.Windows.Forms.TextBox clientTbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox serverTbx;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn FolderPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn FileType;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilePath;
        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.Button deleteFolderBtn;
        private System.Windows.Forms.Button deleteFileBtn;
    }
}