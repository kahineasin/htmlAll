﻿using PF.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ReleaseProject
{
    public class LogInfoModel
    {
        private string _currentVersion;
        public string CurrentVersion {
            get { return _currentVersion ?? "最新"; } set { _currentVersion = value; }
        }
        public LogInfoModel() {

        }
        //public LogInfoModel(string txt) {
        //    var rows = txt.Split(new char[] { '\r','\n'},StringSplitOptions.RemoveEmptyEntries);
        //    CurrentVersion = rows[0].Split(new char[] { ':'})[1];
        //}
        //public string ToTxt() {
        //    var txt = "";
        //    txt += "当前版本:" + _currentVersion+"\r\n";
        //    return txt;
        //}

        public static string GetSysUpdateLogRoot(string sysName) {
            return Path.Combine(ReleaseUtils.AppRoot, "UpdateLog", sysName);
        }
        public static string GetSysUpdateLogInfoPath(string sysName)
        {
            return Path.Combine(GetSysUpdateLogRoot(sysName), "LogInfo.txt");
        }
        public static void SetCurrentVersion(string sysName,string version)
        {
            ZFiles.CreateDirectory(GetSysUpdateLogRoot(sysName));
            var logInfoPath = GetSysUpdateLogInfoPath(sysName);

            //var log = new FileStream(logInfoPath, FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter sw = new StreamWriter(log);
            //File.ReadAllLines(logInfoPath, Encoding.Default);
            //sw
            //sw.WriteLine(sLog);//开始写入值
            //log.Flush();
            //sw.Close();
            //log.Close();
            //log.Dispose();

            //var aa = File.CreateText("aa");
            //aa.
            if (File.Exists(logInfoPath))
            {
                string[] ary = File.ReadAllLines(logInfoPath, Encoding.Default);
                ary[0] = "当前版本:" + version + "\r\n";
                string str = string.Join("\r\n", ary);
                File.WriteAllText(logInfoPath, str);
            }
            else
            {
                var log = new FileStream(logInfoPath, FileMode.CreateNew, FileAccess.Write);
                StreamWriter sw = new StreamWriter(log);
                sw.WriteLine("当前版本:" + version + "\r\n");//开始写入值
                log.Flush();
                sw.Close();
                log.Close();
                log.Dispose();
            }
        }
        public static string GetCurrentVersion(string sysName)
        {
            var logInfoPath = GetSysUpdateLogInfoPath(sysName);
            if (File.Exists(logInfoPath))
            {
                string[] ary = File.ReadAllLines(logInfoPath, Encoding.UTF8);
                return ary[0].Split(new char[] { ':' })[1];
            }
            return "";
        }
        //以后可能要给每个日志一个Tag
        //List<LogInfo>
    }
}
