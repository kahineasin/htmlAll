﻿namespace ReleaseProject
{
    partial class ConfirmCopyFileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.updateDetailDgv = new System.Windows.Forms.DataGridView();
            this.FilePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdateWay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompareInfo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.confirmUpdateBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.updateDetailDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // updateDetailDgv
            // 
            this.updateDetailDgv.AllowUserToAddRows = false;
            this.updateDetailDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.updateDetailDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FilePath,
            this.UpdateWay,
            this.CompareInfo});
            this.updateDetailDgv.Location = new System.Drawing.Point(12, 37);
            this.updateDetailDgv.Name = "updateDetailDgv";
            this.updateDetailDgv.RowTemplate.Height = 23;
            this.updateDetailDgv.Size = new System.Drawing.Size(485, 150);
            this.updateDetailDgv.TabIndex = 0;
            // 
            // FilePath
            // 
            this.FilePath.HeaderText = "FilePath";
            this.FilePath.Name = "FilePath";
            this.FilePath.Width = 200;
            // 
            // UpdateWay
            // 
            this.UpdateWay.HeaderText = "UpdateWay";
            this.UpdateWay.Name = "UpdateWay";
            // 
            // CompareInfo
            // 
            this.CompareInfo.HeaderText = "CompareInfo";
            this.CompareInfo.Name = "CompareInfo";
            // 
            // deleteBtn
            // 
            this.deleteBtn.Location = new System.Drawing.Point(12, 8);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 23);
            this.deleteBtn.TabIndex = 1;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // confirmUpdateBtn
            // 
            this.confirmUpdateBtn.Location = new System.Drawing.Point(13, 194);
            this.confirmUpdateBtn.Name = "confirmUpdateBtn";
            this.confirmUpdateBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmUpdateBtn.TabIndex = 2;
            this.confirmUpdateBtn.Text = "确定复制";
            this.confirmUpdateBtn.UseVisualStyleBackColor = true;
            this.confirmUpdateBtn.Click += new System.EventHandler(this.confirmUpdateBtn_Click);
            // 
            // ConfirmCopyFileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 257);
            this.Controls.Add(this.confirmUpdateBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.updateDetailDgv);
            this.Name = "ConfirmCopyFileForm";
            this.Text = "confirmCopyFileForm";
            ((System.ComponentModel.ISupportInitialize)(this.updateDetailDgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView updateDetailDgv;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button confirmUpdateBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn UpdateWay;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompareInfo;
    }
}