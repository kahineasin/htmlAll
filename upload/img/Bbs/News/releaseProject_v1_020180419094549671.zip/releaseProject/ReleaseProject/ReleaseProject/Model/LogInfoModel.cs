﻿using PF.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ReleaseProject
{
    public class LogInfoModel
    {
        private string _currentVersion;
        public FileStream _logInfo;
        public string CurrentVersion {
            get { return _currentVersion ?? "最新"; } set { _currentVersion = value; }
        }
        //public LogInfoModel() {

        //}
        private void SetRow(string[] rows,int rowIndex,Action<string> action) {
            if (rows.Length > rowIndex)
            {
                if (rows[rowIndex] != null) { action(rows[rowIndex]); }                
            }
        }
        public LogInfoModel(string sysName)
        {
            ZFiles.CreateDirectory(GetSysUpdateLogRoot(sysName));
            var logInfoPath = GetSysUpdateLogInfoPath(sysName);
            _logInfo = new FileStream(logInfoPath, FileMode.OpenOrCreate, FileAccess.ReadWrite);

            _logInfo.Position = 0;
            var fsRead = _logInfo;
            int fsLen = (int)fsRead.Length;
            byte[] heByte = new byte[fsLen];
            int r = fsRead.Read(heByte, 0, heByte.Length);
            string myStr = System.Text.Encoding.UTF8.GetString(heByte);
            var rows = myStr.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            SetRow(rows, 0, a => CurrentVersion = a.Split(new char[] { ':' })[1]);
            //if (rows.Length>0)CurrentVersion=rows[0].Split(new char[] { ':' })[1];
            _logInfo.Position = 0;

            //using (StreamReader reader = new StreamReader(_logInfo, Encoding.UTF8))
            //{
            //    string text = string.Empty;
            //    int i = 0;
            //    while (!reader.EndOfStream)
            //    {
            //        var line = reader.ReadLine();
            //        switch (i)
            //        {
            //            case 0:
            //                CurrentVersion = line.Split(new char[] { ':' })[1];
            //                break;
            //            default:
            //                break;
            //        }
            //        i++;
            //    }
            //}

            ////if (File.Exists(logInfoPath))
            ////{
            ////    string[] ary = File.ReadAllLines(logInfoPath, Encoding.Default);
            ////    CurrentVersion = ary[0].Split(new char[] { ':' })[1];
            ////}
            ////else
            ////{
            ////    var log = new FileStream(logInfoPath, FileMode.CreateNew, FileAccess.Write);
            ////    StreamWriter sw = new StreamWriter(log);
            ////    sw.WriteLine("当前版本:\r\n");//开始写入值
            ////    log.Flush();
            ////    sw.Close();
            ////    log.Close();
            ////    log.Dispose();
            ////}
        }
        public void SaveToTxt()
        {
            var _file = _logInfo;
            _file.Position = 0;
            _file.SetLength(0);
            string msg = "当前版本:" + CurrentVersion+"\r\n";
            byte[] myByte = System.Text.Encoding.UTF8.GetBytes(msg);
            _file.Write(myByte, 0, myByte.Length);
            _file.Flush(true);
            _file.Position = 0;

            //_logInfo.Flush();
            //_logInfo.Position = 0;
            //StreamWriter sw = new StreamWriter(_logInfo);
            //sw.WriteLine("当前版本:" + CurrentVersion);//开始写入值
            //sw.Flush();
            ////log.Flush();
            //sw.Close();
            ////log.Close();
            ////log.Dispose();
            ////_logInfo.Flush();
        }
        public void Dispose()
        {
            _logInfo.Close();
            _logInfo.Dispose();
        }

        public static string GetSysUpdateLogRoot(string sysName) {
            return Path.Combine(ReleaseUtils.AppRoot, "UpdateLog", sysName);
        }
        public static string GetSysUpdateLogInfoPath(string sysName)
        {
            return Path.Combine(GetSysUpdateLogRoot(sysName), "LogInfo.txt");
        }
        //public static void SetCurrentVersion(string sysName,string version)
        //{
        //    ZFiles.CreateDirectory(GetSysUpdateLogRoot(sysName));
        //    var logInfoPath = GetSysUpdateLogInfoPath(sysName);

        //    if (File.Exists(logInfoPath))
        //    {
        //        string[] ary = File.ReadAllLines(logInfoPath, Encoding.Default);
        //        ary[0] = "当前版本:" + version + "\r\n";
        //        string str = string.Join("\r\n", ary);
        //        File.WriteAllText(logInfoPath, str);
        //    }
        //    else
        //    {
        //        var log = new FileStream(logInfoPath, FileMode.CreateNew, FileAccess.Write);
        //        StreamWriter sw = new StreamWriter(log);
        //        sw.WriteLine("当前版本:" + version + "\r\n");//开始写入值
        //        log.Flush();
        //        sw.Close();
        //        log.Close();
        //        log.Dispose();
        //    }
        //}
        //public static string GetCurrentVersion(string sysName)
        //{
        //    var logInfoPath = GetSysUpdateLogInfoPath(sysName);
        //    if (File.Exists(logInfoPath))
        //    {
        //        string[] ary = File.ReadAllLines(logInfoPath, Encoding.UTF8);
        //        return ary[0].Split(new char[] { ':' })[1];
        //    }
        //    return "";
        //}

        //以后可能要给每个日志一个Tag
        //List<LogInfo>
    }
}
