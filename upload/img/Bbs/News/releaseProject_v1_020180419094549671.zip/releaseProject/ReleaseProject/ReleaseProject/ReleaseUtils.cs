﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ReleaseProject
{
    public static class ReleaseUtils
    {
        /// <summary>
        /// 日期生成文件夹时的格式
        /// </summary>
        public static string TimePathFormat = "yyyyMMdd_HHmmss";
        public static string AppRoot = AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "");
        /// <summary>
        /// 写日志时每个字段之间的分隔符号(如果修改，会导致旧日志的回滚功能出错)
        /// </summary>
        public static string LogSplitMark = "\t\t\t";

        #region 增删文件、文件夹
        public static void AddFolderGridRow(DataGridView folderDgv, string folderPath, string fileType)
        {
            DataGridViewRow row = new DataGridViewRow();

            DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
            colNameCell.Value = folderPath;
            row.Cells.Add(colNameCell);

            DataGridViewTextBoxCell colFileType = new DataGridViewTextBoxCell();
            colFileType.Value = fileType;
            row.Cells.Add(colFileType);

            folderDgv.Rows.Add(row);
        }
        public static void AddFolderGridRowByTxt(DataGridView folderDgv, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader reader = new StreamReader(fs, Encoding.UTF8))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var row = line.Split(ReleaseUtils.LogSplitMark.ToArray(), StringSplitOptions.RemoveEmptyEntries);
                        AddFolderGridRow(folderDgv, row[0], row[1]);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                fs.Close();
                fs.Dispose();
            }
        }
        public static void AddFileGridRow(DataGridView fileDgv, string folderPath)
        {
            DataGridViewRow row = new DataGridViewRow();

            DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
            colNameCell.Value = folderPath;
            row.Cells.Add(colNameCell);

            fileDgv.Rows.Add(row);
        }
        public static void AddFileGridRowByTxt(DataGridView folderDgv, string filePath)
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader reader = new StreamReader(fs, Encoding.UTF8))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var row = line.Split(ReleaseUtils.LogSplitMark.ToArray(), StringSplitOptions.RemoveEmptyEntries);
                        AddFileGridRow(folderDgv, row[0]);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                fs.Close();
                fs.Dispose();
            }
        } 
        #endregion
    }
}
