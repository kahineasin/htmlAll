﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PF.Utils;

namespace ReleaseProject
{
    public partial class ConfirmCopyFileForm : Form
    {
        private List<UpdateFileModel> _updateFiles;
        private string _sysName = "";
        private SysModel _sys;
        public ConfirmCopyFileForm()
        {
            InitializeComponent();
        }
        public ConfirmCopyFileForm(SysModel sys, List<UpdateFileModel> updateFiles):this()
        {
            _sys = sys;
            _sysName = sys.SysName;
            _updateFiles = updateFiles;
            foreach (var updateFile in updateFiles)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                colNameCell.Value = updateFile.RelativePath;
                row.Cells.Add(colNameCell);

                DataGridViewTextBoxCell colTypeCell = new DataGridViewTextBoxCell();//DataGridViewComboBoxCell
                colTypeCell.Value = updateFile.UpdateWay.ToString();
                row.Cells.Add(colTypeCell);

                DataGridViewTextBoxCell colNameCNCell = new DataGridViewTextBoxCell();
                colNameCNCell.Value = updateFile.CompareInfo;
                row.Cells.Add(colNameCNCell);

                updateDetailDgv.Rows.Add(row);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            var selects = updateDetailDgv.SelectedRows;
            foreach (DataGridViewRow i in selects)
            {
                if (!i.IsNewRow)
                {
                    updateDetailDgv.Rows.Remove(i);
                }
            }
        }

        private void confirmUpdateBtn_Click(object sender, EventArgs e)
        {
            var ufPath = Path.Combine(ReleaseUtils.AppRoot, "UpdateFile", _sysName, "File");
            if (Directory.Exists(ufPath))
            {
                try
                {
                    Directory.Delete(ufPath, true);
                }
                catch (Exception ex)
                {
                }
            }
            ZFiles.CreateDirectory(ufPath);
            ////DirectoryInfo dir = new DirectoryInfo(ufPath);
            ////if (dir.Exists) { Directory.Delete(ufPath,true); }
            ////dir.Create();
            foreach (DataGridViewRow row in updateDetailDgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    string path = (string)row.Cells[0].Value;
                    var updateFile = _updateFiles.First(a => a.RelativePath == path);
                    ZFiles.CreateDirectory(Path.Combine(ufPath, path.Replace(updateFile.FileName, "")));
                    updateFile.ClientFile.Position = 0;
                    ZFiles.SaveStreamToFileWithoutClose(updateFile.ClientFile, Path.Combine(ufPath,path));
                }
            }
            MessageBox.Show("已成功复制");
        }
        protected override void OnClosed(EventArgs e)
        {
            DisposeFile();
            base.OnClosed(e);
        }
        private void DisposeFile()
        {
            if (_updateFiles != null && _updateFiles.Count > 0)
            {
                foreach (var updateFile in _updateFiles)
                {
                    updateFile.DisposeFile();
                }
                _updateFiles.Clear();
            }
        }
    }
}
