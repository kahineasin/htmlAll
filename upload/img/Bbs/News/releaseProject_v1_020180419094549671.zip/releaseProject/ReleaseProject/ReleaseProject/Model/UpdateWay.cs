﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReleaseProject
{
    /// <summary>
    /// 更新方式
    /// </summary>
    public enum UpdateWay
    {
        /// <summary>
        /// 替换
        /// </summary>
        Replace=1,
        /// <summary>
        /// 新建
        /// </summary>
        New=2,
        /// <summary>
        /// 删除
        /// </summary>
        Delete=4
    }
}
