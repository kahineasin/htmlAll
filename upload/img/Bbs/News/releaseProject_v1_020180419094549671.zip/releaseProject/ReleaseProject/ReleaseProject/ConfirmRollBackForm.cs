﻿using PF.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace ReleaseProject
{
    public delegate void ConfirmDelegateHander(string version); //声明一个委托
    public partial class ConfirmRollBackForm : Form
    {
        public event ConfirmDelegateHander ClickEvent;//声明一个事件
        private string _sysName = "";
        private SysModel _sys;
        private List<RollBackFileModel> _rollBackFiles;
        private string _version = "";
        //private string _logRoot = "";
        public ConfirmRollBackForm()
        {
            InitializeComponent();
        }
        public ConfirmRollBackForm(SysModel sys,List<RollBackFileModel> rollBackFiles,string version):this()
        {
            _sys = sys;
            _sysName = sys.SysName;
            _rollBackFiles = rollBackFiles;
            _version = version;

            ////路径配置
            //_logRoot = Path.Combine(ReleaseUtils.AppRoot, string.Format("UpdateLog\\{0}", _sysName));

            foreach (var rollBackFile in rollBackFiles)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                colNameCell.Value = rollBackFile.RelativePath;
                row.Cells.Add(colNameCell);

                DataGridViewTextBoxCell colTypeCell = new DataGridViewTextBoxCell();//DataGridViewComboBoxCell
                colTypeCell.Value = rollBackFile.RollBackWay;
                row.Cells.Add(colTypeCell);

                rollBackDetailDgv.Rows.Add(row);
            }            
        }

        private void confirmRollBackBtn_Click(object sender, EventArgs e)
        {

            foreach (var rollBackFile in _rollBackFiles)
            {
                var sPath = Path.Combine(_sys.ServerRoot, rollBackFile.RelativePath);
                if (rollBackFile.RollBackWay == UpdateWay.Delete)
                {
                    File.Delete(sPath);
                }
                else if (rollBackFile.RollBackWay == UpdateWay.Replace)
                {
                    rollBackFile.BackupFile.Position = 0;
                    ZFiles.SaveStreamToFile(rollBackFile.BackupFile, sPath);
                }
            }
            MessageBox.Show("已成功回滚到之前版本");

            ////修改当前版本
            var logInfo = new LogInfoModel(_sysName);
            logInfo.CurrentVersion = _version;
            logInfo.SaveToTxt();
            logInfo.Dispose();

            //LogInfoModel.SetCurrentVersion(_sysName, _version);

            ClickEvent(_version);
        }
        protected override void OnClosed(EventArgs e)
        {
            DisposeFile();
            base.OnClosed(e);
        }
        private void DisposeFile()
        {
            if (_rollBackFiles != null && _rollBackFiles.Count > 0)
            {
                foreach (var updateFile in _rollBackFiles)
                {
                    updateFile.DisposeFile();
                }
                _rollBackFiles.Clear();
            }
        }
    }
}
