﻿namespace ReleaseProject
{
    partial class RollBackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logDgv = new System.Windows.Forms.DataGridView();
            this.Log = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openLogBtn = new System.Windows.Forms.Button();
            this.rollBackBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.currentVersionLb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.logDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // logDgv
            // 
            this.logDgv.AllowUserToAddRows = false;
            this.logDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.logDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Log,
            this.LogPath});
            this.logDgv.Location = new System.Drawing.Point(12, 34);
            this.logDgv.Name = "logDgv";
            this.logDgv.RowTemplate.Height = 23;
            this.logDgv.Size = new System.Drawing.Size(468, 150);
            this.logDgv.TabIndex = 0;
            // 
            // Log
            // 
            this.Log.HeaderText = "Log";
            this.Log.Name = "Log";
            this.Log.Width = 200;
            // 
            // LogPath
            // 
            this.LogPath.HeaderText = "LogPath";
            this.LogPath.Name = "LogPath";
            this.LogPath.Width = 200;
            // 
            // openLogBtn
            // 
            this.openLogBtn.Location = new System.Drawing.Point(13, 191);
            this.openLogBtn.Name = "openLogBtn";
            this.openLogBtn.Size = new System.Drawing.Size(75, 23);
            this.openLogBtn.TabIndex = 1;
            this.openLogBtn.Text = "打开日志";
            this.openLogBtn.UseVisualStyleBackColor = true;
            this.openLogBtn.Click += new System.EventHandler(this.openLogBtn_Click);
            // 
            // rollBackBtn
            // 
            this.rollBackBtn.Location = new System.Drawing.Point(94, 190);
            this.rollBackBtn.Name = "rollBackBtn";
            this.rollBackBtn.Size = new System.Drawing.Size(75, 23);
            this.rollBackBtn.TabIndex = 2;
            this.rollBackBtn.Text = "回滚";
            this.rollBackBtn.UseVisualStyleBackColor = true;
            this.rollBackBtn.Click += new System.EventHandler(this.rollBackBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "当前版本:";
            // 
            // currentVersionLb
            // 
            this.currentVersionLb.AutoSize = true;
            this.currentVersionLb.Location = new System.Drawing.Point(72, 13);
            this.currentVersionLb.Name = "currentVersionLb";
            this.currentVersionLb.Size = new System.Drawing.Size(0, 12);
            this.currentVersionLb.TabIndex = 4;
            // 
            // RollBackForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 269);
            this.Controls.Add(this.currentVersionLb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rollBackBtn);
            this.Controls.Add(this.openLogBtn);
            this.Controls.Add(this.logDgv);
            this.Name = "RollBackForm";
            this.Text = "RollBackForm";
            ((System.ComponentModel.ISupportInitialize)(this.logDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView logDgv;
        private System.Windows.Forms.Button openLogBtn;
        private System.Windows.Forms.Button rollBackBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Log;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label currentVersionLb;
    }
}