﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace ReleaseProject
{
    public class SysModel
    {
        public SysModel(XmlNode sys) {

            SysName = sys.Name;
            ClientRoot = sys.SelectSingleNode("Client/SystemRoot").InnerText;
            ServerRoot = sys.SelectSingleNode("Server/SystemRoot").InnerText;
        }
        public string SysName { get; set; }
        public string ClientRoot { get; set; }
        public string ServerRoot { get; set; }
    }
}
