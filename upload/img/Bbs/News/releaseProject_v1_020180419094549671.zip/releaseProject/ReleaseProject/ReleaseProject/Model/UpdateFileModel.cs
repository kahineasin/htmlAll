﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ReleaseProject
{
    public class UpdateFileModel
    {
        public string RelativePath { get; set; }
        public FileStream ClientFile { get; set; }
        public FileStream ServerFile { get; set; }
        public UpdateWay UpdateWay {
            get {
                if (ClientFile == null && ServerFile != null) {
                    return UpdateWay.Delete;
                } else if (ClientFile != null && ServerFile == null)
                {
                    return UpdateWay.New;
                }
                else if (ClientFile != null && ServerFile != null)
                {
                    return UpdateWay.Replace;
                }
                throw new Exception("路径有问题，文件不存在");
            }
        }

        public string CompareInfo {
            get
            {
                if (ClientFile != null && ServerFile != null) {
                    if (ClientFile.Length > ServerFile.Length) {
                        return "更大";
                    }else if (ClientFile.Length < ServerFile.Length)
                    {
                        return "更小";
                    }else {
                        return "相等";
                    }
                }
                return "";
            }
        }
        public string FileName {
            get {
                return Path.GetFileName(RelativePath);
            }
        }
        public void DisposeFile() {
            if (ClientFile != null) {
                ClientFile.Close();
                ClientFile.Dispose();
            }
            if (ServerFile != null)
            {
                ServerFile.Close();
                ServerFile.Dispose();
            }
        }
    }
}
