﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PF.Utils;

namespace ReleaseProject
{
    public partial class ConfirmUpdateForm : Form
    {
        private string _updateFileRoot;
        private List<UpdateFileModel> _updateFiles;
        private string _sysName = "";
        private SysModel _sys;
        public ConfirmUpdateForm()
        {
            InitializeComponent();
        }
        public ConfirmUpdateForm(SysModel sys, List<UpdateFileModel> updateFiles):this()
        {      
            _sys = sys;
            _sysName = sys.SysName;
            _updateFiles = updateFiles;

            //配置路径
            _updateFileRoot = Path.Combine(ReleaseUtils.AppRoot, "UpdateFile", _sysName, "File");

            foreach (var updateFile in updateFiles)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell colNameCell = new DataGridViewTextBoxCell();
                colNameCell.Value = updateFile.RelativePath;
                row.Cells.Add(colNameCell);

                DataGridViewTextBoxCell colTypeCell = new DataGridViewTextBoxCell();//DataGridViewComboBoxCell
                colTypeCell.Value = updateFile.UpdateWay.ToString();
                row.Cells.Add(colTypeCell);

                DataGridViewTextBoxCell colNameCNCell = new DataGridViewTextBoxCell();
                colNameCNCell.Value = updateFile.CompareInfo;
                row.Cells.Add(colNameCNCell);

                updateDetailDgv.Rows.Add(row);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            var selects = updateDetailDgv.SelectedRows;
            foreach (DataGridViewRow i in selects)
            {
                if (!i.IsNewRow)
                {
                    updateDetailDgv.Rows.Remove(i);
                }
            }
        }

        private void confirmUpdateBtn_Click(object sender, EventArgs e)
        {

            #region 日志
            var sLog = "";
            //日志
            var now = DateTime.Now;
            var sTime = now.ToString(ReleaseUtils.TimePathFormat);

            var logRoot = Path.Combine(ReleaseUtils.AppRoot, string.Format("UpdateLog\\{0}\\{1}", _sysName, sTime));
            var logPath = Path.Combine(logRoot, "log.txt");
            ZFiles.CreateDirectory(logRoot);

            foreach (DataGridViewRow row in updateDetailDgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    //日志
                    sLog += string.Format("{0}{3}{1}{3}{2}\r\n", (string)row.Cells[0].Value, (string)row.Cells[1].Value, (string)row.Cells[2].Value, ReleaseUtils.LogSplitMark);

                    //备份文件
                    string path = (string)row.Cells[0].Value;
                    var cPath = Path.Combine(_updateFileRoot, path);//正式时启用这一句 --wxj
                    //var cPath = Path.Combine(_sys.ClientRoot, path);
                    var sPath = Path.Combine(_sys.ServerRoot, path);
                    var updateFile = _updateFiles.First(a => a.RelativePath == path);
                    if (updateFile.ClientFile != null)
                    {
                        var fullPath = Path.Combine(logRoot, "Client", path);
                        ZFiles.CreateDirectory(fullPath.Replace(updateFile.FileName, ""));
                        File.Copy(cPath, fullPath, true);
                    }
                    if (updateFile.ServerFile != null)
                    {
                        var fullPath = Path.Combine(logRoot, "Server", path);
                        ZFiles.CreateDirectory(fullPath.Replace(updateFile.FileName, ""));
                        File.Copy(sPath, fullPath, true);
                    }
                }

            }
            var log = new FileStream(logPath, FileMode.CreateNew, FileAccess.Write);
            StreamWriter sw = new StreamWriter(log);
            sw.WriteLine(sLog);//开始写入值
            sw.Close();
            log.Close();

            #endregion 日志

            //更新文件
            foreach (DataGridViewRow row in updateDetailDgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    string path = (string)row.Cells[0].Value;
                    var updateFile = _updateFiles.First(a => a.RelativePath == path);

                    if (updateFile.UpdateWay == ReleaseProject.UpdateWay.New)
                    {
                        ZFiles.SaveStreamToFile(updateFile.ClientFile, Path.Combine(_sys.ServerRoot, updateFile.RelativePath));
                    }
                    else if (updateFile.UpdateWay == ReleaseProject.UpdateWay.Replace)
                    {
                        updateFile.ClientFile.Position = 0;
                        updateFile.ServerFile.Position = 0;
                        updateFile.ClientFile.CopyTo(updateFile.ServerFile);
                        updateFile.ServerFile.Flush();

                    }
                }
            }

            ////修改当前版本
            var logInfo = new LogInfoModel(_sysName);
            logInfo.CurrentVersion = "最新";
            logInfo.SaveToTxt();
            logInfo.Dispose();

            //LogInfoModel.SetCurrentVersion(_sysName, "最新");

            System.Diagnostics.Process.Start(logPath); //如果是本地访问就直接打开文件夹 


        }
        protected override void OnClosed(EventArgs e)
        {
            DisposeFile();
            base.OnClosed(e);
        }
        private void DisposeFile()
        {
            if (_updateFiles != null && _updateFiles.Count > 0)
            {
                foreach (var updateFile in _updateFiles)
                {
                    updateFile.DisposeFile();
                }
                _updateFiles.Clear();
            }
        }
    }
}
