﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ReleaseProject
{
    public class RollBackFileModel
    {
        public string RelativePath { get; set; }
        /// <summary>
        /// 回滚方式
        /// </summary>
        public UpdateWay RollBackWay { get; set; }

        /// <summary>
        /// 备份文件
        /// </summary>
        public FileStream BackupFile { get; set; }

        public RollBackFileModel(string txtLine) {
            
            var row = txtLine.Split(ReleaseUtils.LogSplitMark.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            RelativePath = row[0];
            UpdateWay eWay;
            if (Enum.TryParse(row[1], out eWay)) {
                switch (eWay) {
                    case UpdateWay.New:
                        RollBackWay = UpdateWay.Delete;
                        break;
                    case UpdateWay.Replace:
                        RollBackWay = eWay;
                        break;
                    default:
                        throw new Exception("无法计算正确的回滚方式");
                        break;
                }
            }
        }
        public string FileName
        {
            get
            {
                return Path.GetFileName(RelativePath);
            }
        }
        public void DisposeFile()
        {
            if (BackupFile != null)
            {
                BackupFile.Close();
                BackupFile.Dispose();
            }
        }

    }
}
