﻿namespace ReleaseProject
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.updateBtn = new System.Windows.Forms.Button();
            this.sysDgv = new System.Windows.Forms.DataGridView();
            this.SysName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.copyFileBtn = new System.Windows.Forms.Button();
            this.rollBackBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sysDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // updateBtn
            // 
            this.updateBtn.Location = new System.Drawing.Point(248, 219);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(197, 23);
            this.updateBtn.TabIndex = 0;
            this.updateBtn.Text = "更新文件";
            this.updateBtn.UseVisualStyleBackColor = true;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // sysDgv
            // 
            this.sysDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sysDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SysName});
            this.sysDgv.Location = new System.Drawing.Point(12, 41);
            this.sysDgv.Name = "sysDgv";
            this.sysDgv.RowTemplate.Height = 23;
            this.sysDgv.Size = new System.Drawing.Size(240, 150);
            this.sysDgv.TabIndex = 1;
            // 
            // SysName
            // 
            this.SysName.HeaderText = "SysName";
            this.SysName.Name = "SysName";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "选择系统";
            // 
            // copyFileBtn
            // 
            this.copyFileBtn.Location = new System.Drawing.Point(12, 219);
            this.copyFileBtn.Name = "copyFileBtn";
            this.copyFileBtn.Size = new System.Drawing.Size(197, 23);
            this.copyFileBtn.TabIndex = 3;
            this.copyFileBtn.Text = "复制出目录和文件";
            this.copyFileBtn.UseVisualStyleBackColor = true;
            this.copyFileBtn.Click += new System.EventHandler(this.copyFileBtn_Click);
            // 
            // rollBackBtn
            // 
            this.rollBackBtn.Location = new System.Drawing.Point(248, 248);
            this.rollBackBtn.Name = "rollBackBtn";
            this.rollBackBtn.Size = new System.Drawing.Size(197, 23);
            this.rollBackBtn.TabIndex = 4;
            this.rollBackBtn.Text = "从日志中恢复";
            this.rollBackBtn.UseVisualStyleBackColor = true;
            this.rollBackBtn.Click += new System.EventHandler(this.rollBackBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "开发端使用:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(248, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "服务器端使用:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 417);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rollBackBtn);
            this.Controls.Add(this.copyFileBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sysDgv);
            this.Controls.Add(this.updateBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.sysDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.DataGridView sysDgv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SysName;
        private System.Windows.Forms.Button copyFileBtn;
        private System.Windows.Forms.Button rollBackBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

