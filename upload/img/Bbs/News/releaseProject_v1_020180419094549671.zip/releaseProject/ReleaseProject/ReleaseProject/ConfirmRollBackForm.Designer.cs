﻿namespace ReleaseProject
{
    partial class ConfirmRollBackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rollBackDetailDgv = new System.Windows.Forms.DataGridView();
            this.confirmRollBackBtn = new System.Windows.Forms.Button();
            this.RelativePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RollBackWay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.rollBackDetailDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // rollBackDetailDgv
            // 
            this.rollBackDetailDgv.AllowUserToAddRows = false;
            this.rollBackDetailDgv.AllowUserToDeleteRows = false;
            this.rollBackDetailDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rollBackDetailDgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RelativePath,
            this.RollBackWay});
            this.rollBackDetailDgv.Location = new System.Drawing.Point(13, 13);
            this.rollBackDetailDgv.Name = "rollBackDetailDgv";
            this.rollBackDetailDgv.RowTemplate.Height = 23;
            this.rollBackDetailDgv.Size = new System.Drawing.Size(349, 150);
            this.rollBackDetailDgv.TabIndex = 0;
            // 
            // confirmRollBackBtn
            // 
            this.confirmRollBackBtn.Location = new System.Drawing.Point(13, 170);
            this.confirmRollBackBtn.Name = "confirmRollBackBtn";
            this.confirmRollBackBtn.Size = new System.Drawing.Size(75, 23);
            this.confirmRollBackBtn.TabIndex = 1;
            this.confirmRollBackBtn.Text = "确认回滚";
            this.confirmRollBackBtn.UseVisualStyleBackColor = true;
            this.confirmRollBackBtn.Click += new System.EventHandler(this.confirmRollBackBtn_Click);
            // 
            // RelativePath
            // 
            this.RelativePath.HeaderText = "RelativePath";
            this.RelativePath.Name = "RelativePath";
            this.RelativePath.Width = 200;
            // 
            // RollBackWay
            // 
            this.RollBackWay.HeaderText = "RollBackWay";
            this.RollBackWay.Name = "RollBackWay";
            // 
            // ConfirmRollBackForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 262);
            this.Controls.Add(this.confirmRollBackBtn);
            this.Controls.Add(this.rollBackDetailDgv);
            this.Name = "ConfirmRollBackForm";
            this.Text = "ConfirmRollBackForm";
            ((System.ComponentModel.ISupportInitialize)(this.rollBackDetailDgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView rollBackDetailDgv;
        private System.Windows.Forms.Button confirmRollBackBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RelativePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn RollBackWay;
    }
}