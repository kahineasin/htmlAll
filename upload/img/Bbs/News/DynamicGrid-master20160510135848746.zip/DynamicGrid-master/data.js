[
    {"Data":"2012-09-08 10:48:24.0","Name":"Adam","Result":"4.01"},
    {"Data":"2012-09-08 10:48:34.0","Name":"Carol","Result":"5.26"},
    {"Data":"2012-09-08 10:48:52.0","Name":'Jim',"Result":"6.66"},
    {"Data":"2012-09-08 10:49:02.0","Name":'Jeniffer',"Result":"6.47"},
    {"Data":"2012-09-08 10:49:12.0","Name":'Joanna',"Result":"6.62"},
    {"Data":"2012-09-08 10:49:22.0","Name":'David',"Result":"5.98"},
    {"Data":"2012-09-08 10:49:32.0","Name":'Lukas',"Result":"5.29"},
    {"Data":"2012-09-08 10:49:42.0","Name":'Piter',"Result":"4.12"}
]