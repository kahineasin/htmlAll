﻿# 待改善的地方

1. getToken 时会影响原 token 的有效性,不知有没有别的 api 可以获得之前的 token

# 发布

1. 打包 release/web 到 zip 里
2. 上传到云平台->test 分组里
3. 访问地址 http://uat-cloud.perfect99.com:10039/

# 测试地址:

http://uat-cloud.perfect99.com:10142/NSCloud/SNSAPI/DataMetabase/GetTableBySourceShortId
http://uat-cloud.perfect99.com:10142/NSCloud/SNSAPI/DataMetabase/GetTableColumnsByMetaShortId
